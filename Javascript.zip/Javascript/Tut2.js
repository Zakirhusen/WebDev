// Data types Two types primitive Datatypes and reference Datatype
// primitive Datatypes strings ,numbers,boolian,Null,undefined,symbol
// reference Datatype are Array,Object literals ,Functions,Date etc


// strings
let string='zak"s';
console.log("datatype is "+typeof string);

// nubers
let num=29;
console.log("datatype is "+typeof num);

// Boolian
let isCar=true;
console.log("datatype is "+typeof isCar);

// Undefined
let undef=undefined;
console.log("datatype is "+typeof undef);

// actully null primitive datatype it shows object
let nullvar=null;
console.log("datatype is "+typeof nullvar);

let arr=[1,2,3,4];
console.log("datatype is "+typeof(arr) +arr);
console.log(arr);
// Object Literal
let stMarks={
    hafeez:80,
    huzaifa:90,
}
console.log("datatype is "+typeof(stMarks))





