//````````````````````` OOps object ,object prototype,prototype inheritance  `````````````````````
console.log('tut23');
let obj={
    name:"quallis",
    speed:90
}
console.log(obj);
//Creating  Object by constructer
let generalCar=function(givenName,givenSpeed){
    this.name=givenName;
    this.speed=givenSpeed
    this.run=function(){
        console.log(`${this.name} is running at speed of ${this.speed}`);
    }
}

let car1=new generalCar("maruti 800",70)
let car2=new generalCar("Nissan",90)
console.log(car1);
// console.log(car1.speed);
// car1.run();

// console.log(car2.name);


// we can edit our prototype 
// generalCar.prototype.color='white'
// generalCar.prototype.getName=function(){
//     return this.name
// }

// console.log(car1.color);
// console.log(car2.getName());

// we cant use prototype too much instead we use classes