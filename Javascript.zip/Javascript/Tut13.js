
// console.log(typeof window);
// console.log(window);
// window.alert("hi")

// window object global automatically so can call window method directly as shown below
// alert("hi")
// prompt("Enter Your Name")

// a=confirm("Are You Sure")

// console.log(innerHeight);
// console.log(innerWidth);

// a = scrollX;
// a = scrollY;
// a=location
// a=location.href
// a=location.href="//facebook.com"
// a=location.toString();
// a=location.reload();
a=history;
a=history.length;
a=history.go(-1);
console.log(a);
