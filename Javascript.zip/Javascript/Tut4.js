let a=80;
let b=70;
// let a=50;
let c=90;
a=90;
// console.log(a++)
// console.log(a);
// operators in javascript
// console.log(a+b);

// operators
// unary operator-->operates on single operand ex(-19)
// unary operator-->operates on two operand ex(110-19)
// console.log("value of a+b="+(a+b));

// console.log("value of a-b="+(a-b));
// console.log("value of a*b="+(a*b));
// console.log("value of a/b="+(a/b));

// post-increment
// console.log("value of a++="+(a++));

// pre-increment
// console.log("value of ++a="+(++a));

// logical AND and OR operator
console.log(a>b&&c>b)
console.log(a>b|c>b)  
