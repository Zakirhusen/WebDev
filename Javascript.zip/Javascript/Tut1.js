// Vairables var,let,const
// varialbles cant start with numbers,special char except _,$
// var is global level scope ,we can change value anywhere
// let and const block level scope
// Value of let we change after define
// Const value cant be change once it defined


// var fname="harry";
// var lname="richard";
// var fname="david"
// console.log(`first name is ${fname} lastname ${lname}`)'

// let fname="david";
// let lname="richard";
// we cant declare let with same name
// let fname="harry";
    // fname="harry";
// console.log(`first name is ${fname} lastname ${lname}`);

// {
//     // block level scope
//     let fname="richard";
//     const pi=6.142;
// }

// const pi=3.142;
// pi=4.12;   we cant do like this 
// console.log(pi);

// const arr1=[10,20,39,40];
// arr1.push(50) we can do like this
// console.log(arr1);
